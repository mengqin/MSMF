
debug() {

if [ $# -gt 0 ]; then
	pid=$(ps | grep httpr | grep $1 | awk '{print $1}')
	echo "Hooking on $pid"
	if [ "$pid" -gt 0 ] 2>/dev/null; then
		r=`./gdb -p $pid 2>&1 < ./gdb.sc`
		if [ -e core* ]; then
			tar zcvf ./debug0526560-result.tar.gz ./core*
		fi
		echo "$r" > ./debug0526560-result.log
		mv ./debug0526560-result.log /var/log/crash
		if [ -e debug0526560-result.tar.gz ]; then 
			mv ./debug0526560-result.tar.gz /var/log/crash
		fi
	else
		echo "couldn't find VS."
	fi
else
	echo "Usage $0 <vs-name>"
fi
}

debug $@ &

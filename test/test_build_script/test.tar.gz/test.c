#include <stdio.h>

int test()
{
	return 0;
}
